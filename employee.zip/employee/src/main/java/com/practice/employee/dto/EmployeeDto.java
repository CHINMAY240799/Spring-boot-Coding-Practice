package com.practice.employee.dto;


public class EmployeeDto {
	
	 private String name;
     private String department;
     private boolean manager;
	
     public String getName() {
		return name;
	}

	 public void setName(String name) {
		 this.name = name;
	 }

	 public String getDepartment() {
		 return department;
	 }

	 public void setDepartment(String department) {
		 this.department = department;
	 }

	 public boolean isManager() {
		 return manager;
	 }

	 public void setManager(boolean manager) {
		 this.manager = manager;
	 }

	 public EmployeeDto(String name, String department, boolean manager) {
		super();
		this.name = name;
		this.department = department;
		this.manager = manager;
	}

     
     
}
