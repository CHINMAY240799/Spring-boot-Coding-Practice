package com.practice.employee.controller;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import com.practice.employee.dto.EmployeeDto;
import com.practice.employee.service.RegisterService;

@RequestMapping("/api/employee")
public class EmployeeController {

   	public RegisterService registerService;
   	
   	public EmployeeController(RegisterService registerService) {
   		
   		this.registerService = registerService;
   		
   	}
   	
     
   	@PostMapping("/register")
   	public String registerEmployee(@RequestBody EmployeeDto request) {
   	   registerService.registerEmployee(request);
   	   return "Employee Added Successfully";
   	}
}
