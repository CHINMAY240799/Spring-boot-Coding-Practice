package com.practice.employee.service;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.practice.employee.dto.EmployeeDto;
import com.practice.employee.entity.Employee;
import com.practice.employee.repository.RegisterRepository;

@Service
public class RegisterService {

	public RegisterRepository registerRepository;
	
	public RegisterService(RegisterRepository registerRepository) {
		this.registerRepository = registerRepository;
	}
	
    
	@Transactional
	public void registerEmployee(EmployeeDto employeeDto) {
		 
		String name = employeeDto.getName();
		String department = employeeDto.getName();
		boolean manager = employeeDto.isManager();
		 
		Employee employee = new Employee(name,department,manager);
		
		if(manager == true)
			employee.setSalary(1000);
		else
			employee.setSalary(500);
		
		registerRepository.save(employee);
	
		
	}
}
